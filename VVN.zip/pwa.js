(function(){
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(()=>{}));
  }
  // Khi chạy như app độc lập (không có thanh trình duyệt), thêm nút nhỏ để quay về menu
  var standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  var isHome = /(^|\/)(index\.html)?$/.test(location.pathname);
  if (standalone && !isHome) {
    window.addEventListener('DOMContentLoaded', function(){
      var b = document.createElement('button');
      b.textContent = '\u2302';
      b.setAttribute('aria-label','Về menu chính');
      b.style.cssText = 'position:fixed;right:6px;bottom:max(6px,env(safe-area-inset-bottom));z-index:99999;width:30px;height:30px;border-radius:50%;border:0;background:rgba(0,0,0,.35);color:#fff;font-size:16px;line-height:30px;padding:0;opacity:.35;cursor:pointer';
      b.onclick = function(){ if (confirm('Thoát về menu chính? Kết nối phòng hiện tại sẽ bị ngắt.')) location.href = 'index.html'; };
      document.body.appendChild(b);
    });
  }
})();

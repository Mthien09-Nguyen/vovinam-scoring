# Hệ thống chấm điểm Vovinam – Ứng dụng PWA (Android · iOS · Windows)

Gồm: `index.html` (menu), `quyen.html` (Quyền), `doi-khang.html` (Đối kháng), `manifest.webmanifest`, `sw.js`, `pwa.js`, thư mục `icons/`.

## 1. Đưa lên web (làm 1 lần, miễn phí)
PWA **bắt buộc chạy qua HTTPS** (mở file trực tiếp từ máy sẽ không cài được). Chọn 1 trong các cách:
- **Netlify Drop**: vào https://app.netlify.com/drop → kéo thả cả thư mục này vào → nhận link `https://...netlify.app`.
- **Cloudflare Pages / GitHub Pages / Vercel**: tải thư mục lên, bật hosting tĩnh.

## 2. Cài trên từng thiết bị
- **Android**: Chrome → mở link → “Cài đặt ứng dụng”.
- **iOS**: Safari → mở link → Chia sẻ → “Thêm vào Màn hình chính”.
- **Windows**: Edge/Chrome → mở link → bấm biểu tượng cài đặt ở thanh địa chỉ.

## 3. Lưu ý
- Lần đầu mở cần Internet để app tự lưu thư viện (PeerJS, Tailwind, font). Sau đó giao diện mở được cả khi mạng yếu.
- Kết nối giữa các máy (mã phòng) vẫn dùng PeerJS nên **cần Internet** khi thi đấu.
- Khi cập nhật file, đổi `VERSION` trong `sw.js` (vd `vovinam-v2`) để máy người dùng nhận bản mới.

## 4. Mật khẩu vào app
- Mở `index.html` sẽ hiện màn hình **Nhập mật khẩu**. Mật khẩu mặc định: `vovinam`.
- **Đổi mật khẩu ngay trong app (không cần sửa file)**: sau khi nhập mật khẩu vào trang chủ, bấm nút **"Đổi mật khẩu"** (dưới cùng) → nhập mật khẩu hiện tại + mật khẩu mới + xác nhận → Lưu. Mật khẩu mới lưu trên chính thiết bị đó.
- **Đặt lại về mặc định**: trong cùng hộp thoại, bấm "Đặt lại về mặc định" (cần nhập đúng mật khẩu hiện tại), hoặc gỡ app / xóa dữ liệu trình duyệt → quay về `vovinam`.
- **Đổi mật khẩu mặc định trong file** (áp dụng cho mọi thiết bị mới cài): mở `lock.js`, sửa dòng `var APP_PASSWORD = 'vovinam';`.
- Lưu ý: mật khẩu đổi trong app chỉ có hiệu lực trên từng thiết bị (không đồng bộ giữa các máy). Đây là khóa phía client (file tĩnh), chỉ ngăn người dùng thông thường; ai biết xem mã nguồn vẫn có thể bỏ qua.
- Sau khi nhập đúng, cả phiên làm việc không hỏi lại; tắt app/mở lại sẽ hỏi lại.
- Bản này đã đổi `VERSION` trong `sw.js` lên `vovinam-v5`; bản cũ trên điện thoại tự cập nhật sau khi mở lại (cần mạng lần đầu).

const VERSION = 'vovinam-v14';
const LOCAL = ['./','index.html','quyen.html','doi-khang.html','pwa.js','lock.js','logo.png','wordmark.png','change-password.js','app-font.css','manifest.webmanifest',
  'icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png','icons/favicon-32.png'];
const CDN = [
  'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js',
  'https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js',
  'https://cdn.tailwindcss.com/',
  'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap'
];
const CACHEABLE_HOSTS = ['unpkg.com','cdn.tailwindcss.com','fonts.googleapis.com','fonts.gstatic.com'];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(VERSION);
    await c.addAll(LOCAL);
    // CDN: lỗi mạng cũng không làm hỏng việc cài đặt
    await Promise.all(CDN.map(u => fetch(u, {mode:'no-cors'}).then(r => c.put(u, r)).catch(()=>{})));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== VERSION) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === location.origin;
  if (!sameOrigin && !CACHEABLE_HOSTS.includes(url.hostname)) return; // PeerJS signaling, STUN/TURN: đi thẳng ra mạng

  e.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const cached = await cache.match(req, {ignoreSearch: sameOrigin});
    const refresh = fetch(req).then(r => {
      if (r && (r.ok || r.type === 'opaque')) cache.put(req, r.clone());
      return r;
    }).catch(() => null);
    if (cached) { e.waitUntil(refresh); return cached; }
    const net = await refresh;
    if (net) return net;
    if (req.mode === 'navigate') return (await cache.match('index.html')) || Response.error();
    return Response.error();
  })());
});
